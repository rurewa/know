1. Download arduin IDE

   Download Link: http://arduino.cc/en/Main/Software

2. Download USB to Serial Chip Driver

   Download Link: http://www.wch.cn/download/CH341SER_EXE.html
   If you use MAC OS, download from http://www.wch.cn/download/CH341SER_MAC_ZIP.html 

3. Before plugging the USB cable to the PC, you should install the driver first.

4. Plug it to your PC with the USB cable and it will automatically install USB interface driver. 

5. Select the corresponding COM port and boar type(Arduino UNO).

6. Open the Arduino IDE and open the sketch "Basics/Blink", and then upload it to UNO R3 to test your board.

7. Any questions about the using this product, please contact us (open_smart@163.com).