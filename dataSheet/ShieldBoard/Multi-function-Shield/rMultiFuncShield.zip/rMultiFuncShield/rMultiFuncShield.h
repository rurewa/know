//Library to control the Arduino MultiFunctionShield
//Based upon this Library http://files.cohesivecomputing.co.uk/MultiFuncShield-Library.zip
//Documentation used https://www.mpja.com/download/hackatronics-arduino-multi-function-shield.pdf
//Libraries required:
//TimerOne - https://github.com/PaulStoffregen/TimerOne
//SoftwareI2C - http://playground.arduino.cc/Main/SoftwareI2CLibrary
#pragma once
#include "B4RDefines.h"
#include "MultiFuncShield.h"
//~Author: Robert W.B. Linn
//~Version: 0.9
namespace B4R {
	//~shortname: MultiFuncShield
	//~Event: ButtonPressed(Buttons as Byte) 
	class B4RMultiFuncShield {
		private:
			//Button Event
			Byte ButtonCurrentValue;
			//~hide
			void (*Event)(Byte NewValue);
			static void buttonlooper(void* b); 
		public:

			//***
			// Defines additional to MultiFuncShield.h to cover Arduino specific constants
			//***

			//HIGH and LOW from Arduino.h = 0x1, 0x0
      #define /*Byte HIGH;*/	B4RMultiFuncShield_LOW HIGH
      #define /*Byte LOW;*/	B4RMultiFuncShield_LOW LOW

			//***
			// Defines from MultiFuncShield.h
			//***

      #define /*Byte ON;*/	B4RMultiFuncShield_ON 1
      #define /*Byte OFF;*/ B4RMultiFuncShield_OFF 0
      #define /*Byte LED_1_PIN;*/	B4RMultiFuncShield_LED_1_PIN 13
      #define /*Byte LED_2_PIN;*/  B4RMultiFuncShield_LED_2_PIN 12
      #define /*Byte LED_3_PIN;*/  B4RMultiFuncShield_LED_3_PIN 11
      #define /*Byte LED_4_PIN;*/  B4RMultiFuncShield_LED_4_PIN 10
      #define /*Byte POT_PIN;*/		B4RMultiFuncShield_POT_PIN 0
      #define /*Byte BEEPER_PIN;*/ B4RMultiFuncShield_BEEPER_PIN 3
      #define /*Byte BUTTON_1_PIN;*/  B4RMultiFuncShield_BUTTON_1_PIN A1
      #define /*Byte BUTTON_2_PIN;*/  B4RMultiFuncShield_BUTTON_2_PIN A2
      #define /*Byte BUTTON_3_PIN;*/  B4RMultiFuncShield_BUTTON_3_PIN A3
      #define /*Byte LATCH_PIN;*/	B4RMultiFuncShield_LATCH_PIN 4
      #define /*Byte CLK_PIN;*/		B4RMultiFuncShield_CLK_PIN 7
      #define /*Byte DATA_PIN;*/   B4RMultiFuncShield_DATA_PIN 8
      #define /*Byte LM35_PIN;*/		B4RMultiFuncShield_LM35_PIN A4
      #define /*Byte DIGIT_1;*/  B4RMultiFuncShield_DIGIT_1 1
      #define /*Byte DIGIT_2;*/  B4RMultiFuncShield_DIGIT_2 2
      #define /*Byte DIGIT_3;*/  B4RMultiFuncShield_DIGIT_3 4
      #define /*Byte DIGIT_4;*/  B4RMultiFuncShield_DIGIT_4 8
      #define /*Byte DIGIT_ALL;*/  B4RMultiFuncShield_DIGIT_ALL 15
      #define /*Byte LED_1;*/  B4RMultiFuncShield_LED_1 1
      #define /*Byte LED_2;*/  B4RMultiFuncShield_LED_2 2
      #define /*Byte LED_3;*/  B4RMultiFuncShield_LED_3 4
      #define /*Byte LED_4;*/  B4RMultiFuncShield_LED_4 8
      #define /*Byte LED_ALL;*/  B4RMultiFuncShield_LED_ALL 15
      #define /*Byte BUTTON_PRESSED_IND;*/			B4RMultiFuncShield_BUTTON_PRESSED_IND (0 << 6)
      #define /*Byte BUTTON_SHORT_RELEASE_IND;*/  B4RMultiFuncShield_BUTTON_SHORT_RELEASE_IND (1 << 6)
      #define /*Byte BUTTON_LONG_PRESSED_IND;*/   B4RMultiFuncShield_BUTTON_LONG_PRESSED_IND (2 << 6)
      #define /*Byte BUTTON_LONG_RELEASE_IND;*/   B4RMultiFuncShield_BUTTON_LONG_RELEASE_IND (3 << 6)
      #define /*Byte BUTTON_1_PRESSED;*/        B4RMultiFuncShield_BUTTON_1_PRESSED (1 |  BUTTON_PRESSED_IND)
      #define /*Byte BUTTON_1_SHORT_RELEASE;*/  B4RMultiFuncShield_BUTTON_1_SHORT_RELEASE (1 |  BUTTON_SHORT_RELEASE_IND)
      #define /*Byte BUTTON_1_LONG_PRESSED;*/   B4RMultiFuncShield_BUTTON_1_LONG_PRESSED (1 |  BUTTON_LONG_PRESSED_IND)
      #define /*Byte BUTTON_1_LONG_RELEASE;*/   B4RMultiFuncShield_BUTTON_1_LONG_RELEASE (1 |  BUTTON_LONG_RELEASE_IND)
      #define /*Byte BUTTON_2_PRESSED;*/        B4RMultiFuncShield_BUTTON_2_PRESSED (2 |  BUTTON_PRESSED_IND)
      #define /*Byte BUTTON_2_SHORT_RELEASE;*/  B4RMultiFuncShield_BUTTON_2_SHORT_RELEASE (2 |  BUTTON_SHORT_RELEASE_IND)
      #define /*Byte BUTTON_2_LONG_PRESSED;*/   B4RMultiFuncShield_BUTTON_2_LONG_PRESSED (2 |  BUTTON_LONG_PRESSED_IND)
      #define /*Byte BUTTON_2_LONG_RELEASE;*/   B4RMultiFuncShield_BUTTON_2_LONG_RELEASE (2 |  BUTTON_LONG_RELEASE_IND)
      #define /*Byte BUTTON_3_PRESSED;*/        B4RMultiFuncShield_BUTTON_3_PRESSED (3 |  BUTTON_PRESSED_IND)
      #define /*Byte BUTTON_3_SHORT_RELEASE;*/  B4RMultiFuncShield_Byte BUTTON_3_SHORT_RELEASE (3 |  BUTTON_SHORT_RELEASE_IND)
      #define /*Byte BUTTON_3_LONG_PRESSED;*/   B4RMultiFuncShield_Byte BUTTON_3_LONG_PRESSED (3 |  BUTTON_LONG_PRESSED_IND)
      #define /*Byte BUTTON_3_LONG_RELEASE;*/   B4RMultiFuncShield_BUTTON_3_LONG_RELEASE (3 |  BUTTON_LONG_RELEASE_IND)
      #define /*Byte SMOOTHING_NONE;*/          B4RMultiFuncShield_SMOOTHING_NONE 0
      #define /*Byte SMOOTHING_MODERATE;*/      B4RMultiFuncShield_SMOOTHING_MODERATE 1
      #define /*Byte SMOOTHING_STRONG;*/        B4RMultiFuncShield_SMOOTHING_STRONG 2

			//FUNCTIONS
	    //void (*userInterrupt)() = NULL;

	   	/**
    	*Initializes this instance, but interrupt based features are not available.
    	*/
    	void Initialize();

    	/**
    	*Initializes this instance using a TimerOne instance. A 1khz interrupt is attached. 
    	*/
    	void InitializeWithTimer();

    	/**
    	*Initializes this instance using a TimerOne instance and adds a looper. A 1khz interrupt is attached. 
    	*Recommend to use when possible a timer instead if the looper contains a delay.
    	*The looper runs as fast as it cans depending board.
    	*/
    	void InitializeWithTimerLooper(SubVoidVoid SubName);

	    // For internal use only.
  	  // void IsrCallBack();

			// ***
			// TIMER
			// ***
    
			/**
			*Initiates a millisecond countdown timer.
			*/
    	void SetTimer (ULong thousandths);

    	/**
    	*Gets the current value of the countdown timer.
    	*/
    	ULong GetTimer();

    	/**
    	*Initiates and waits for millisecond countdown timer to reach 0.
    	*/
    	void Wait(ULong thousandths);

			// ***
			// LED 4-DIGIT DISPLAY
			// ***
    
    	/**
    	*Write a max 4 character string to the LED digit display. Rightjustify: 0 | 1.
    	*Example:<code>
    	*WriteString("Hi",1)
    	*</code>
    	*/
    	void WriteString(B4RString* string, Byte rightJustify = 0);

			/**
			*Write an integer to the LED digit display.
    	*Example:<code>
    	*WriteInt(1958)
    	*</code>
			*/
    	void WriteInt(Int integer);

			/**
			*Write a double (float) to the LED digit display.
    	*Example:<code>
    	*WriteDouble(19.58,2)
    	*</code>
			*/
    	void WriteDouble(Double number, Byte decimalPlaces = 1);
    
    	/**
    	*Manually refreshes the Led digit display.
    	*IMPORTANT: Not to be used whilst interrupt based features are available.
    	*/
    	void ManualDisplayRefresh();
    
    	/**
    	*Blinks digits on the LED digit display.
	    *digits - use bitwise or, e.g. DIGIT_1 | DIGIT_2
      *enabled - turns on/off the blinking
    	*Example (Private mfs As MultiFuncShield):<code>
    	*BlinkDisplay(mfs.DIGIT_ALL, mfs.ON))
    	*BlinkDisplay(Bit.Or(mfs.DIGIT_3, mfs.DIGIT_4), mfs.ON)
    	*</code>
    	*/
	    void BlinkDisplay(Byte digits, Byte enabled = ON);
    
    	/**
    	*Turns LEDs on or off.
    	*leds - use bitwise or, e.g. LED_1 | LED_2
      *lit- ON or OFF
    	*Example (Private mfs As MultiFuncShield):<code>
    	*WriteLeds(Bit.Or(mfs.LED_1, mfs.LED_2), mfs.ON)
			*WriteLeds(mfs.LED_ALL, mfs.OFF)
    	*</code>
    	*/
    	void WriteLeds(Byte leds, Byte lit);

    	/**
    	*Blinks the LEDs.
    	*leds - use bitwise or, e.g. LED_1 | LED_2
      *enabled - ON or OFF
    	*Example (Private mfs As MultiFuncShield):<code>
			*BlinkLeds(Bit.Or(mfs.LED_1, mfs.LED_2), mfs.ON)
    	*</code>
    	*/
    	void BlinkLeds(Byte leds, Byte enabled = ON);

			//***
			// BEEP
			//***

	    /**
	    *Engage the beeper, which is managed in the background. Period timing is in 100th of second
	    *onPeriod - beep for nn milliseconds (e.g. 20)
			*offPeriod - silent for nn milliseconds (e.g. 0)
			*cycle - repeat above cycle n times (e.g. 1)
			*loopCycles - loop n times (0=indefinitely) (e.g. 3)
			*loopDelayPeriod - wait nn milliseconds between Loop (e.g. 50)
    	*Example (Private mfs As MultiFuncShield):<code>
			*'Beep one time for 10ms
			*Beep(1,0,1,1,0)
    	*</code>
	    */
  	  void Beep(UInt onPeriod, UInt offPeriod, Byte cycles, UInt loopCycles, UInt loopDelayPeriod);

    	/**
    	*Use this to set the off period whilst the beeper is engaged
    	*Example (Private mfs As MultiFuncShield):<code>
			*SetBeepOffPeriod(1000)
    	*</code>
    	*/
    	void SetBeepOffPeriod(UInt offPeriod);

			//***
			// BUTTONS
			//***

	    // Queues a button action to the button queue, e.g BUTTON_1_PRESSED
    	//~hide
  	  void QueueButton (Byte button);

    	/**
    	*Pulls a button action from the button queue.
    	*/
    	//~hide
    	Byte GetButton();

    	/**
    	*Queues button short press and release actions. Long button presses are not supported, and long releases are reported as short releases.
    	*Should not be used whilst interrupt based features are available.
    	**/
    	void ManualButtonHandler();
        	
			/**
			*Adds a button listener.
			*Example (Private mfs As MultiFuncShield):<code>
			*'Add the buttonlistener
			*AddButtonListener("mfs_ButtonPressed")
			*
      *Private Sub mfs_ButtonPressed(btn As Byte)
      *	Select btn
      *		Case mfs.BUTTON_1_PRESSED
      *			'Action
      *		Case mfs.BUTTON_2_PRESSED
      *			'Action
      *	End Select
      *End Sub
			*</code>
			*/
			void AddButtonListener(SubVoidByte ButtonPressedSub); 

			//***
			// PULSEIN
			//***
    
    	/**
    	*Initializes the pulse counter. Used for counting pulses applied to an input pin. Max pulse frequency 500hz.
    	*Byte pin - input pin. e.g. BUTTON_1_PIN
			*UInt timeOut - number of milliseconds to wait for a pulse, before resetting pulse in period to 0. e.g. 3000
      *Byte trigger - trigger counter on either rising or falling edge. e.g. LOW
			*Example (Private mfs As MultiFuncShield):<code>
			*'Button 1 = generate pulses
			*'1500 = number of milliseconds waiting for a pulse, before resetting pulse in period to 0.
			*'LOW =  trigger pulse on LOW input.
			*InitPulseInCounter(mfs.BUTTON_1_PIN, 1500, mfs.LOW)
			*</code>
    	*/
    	void InitPulseInCounter(Byte pin, UInt timeOut, Byte trigger);

			/**
			*Disable the pulse counter.
			*/
    	void DisablePulseInCounter();
    
    	/**
    	*Gets the period of the most recent pulse (in milliseconds).
    	*/
    	UInt GetPulseInPeriod();

    	/**
    	*Gets the total number pulses counted.
    	*/
    	ULong GetPulseInTotalCount();

    	/**
    	*Resets the pulse counter to 0.
    	*/
    	void ResetPulseInTotalCount();

    	/**
    	*Sets the pulse in timeout, which is the number of milliseconds to wait for a pulse, before resetting pulse in period to 0.
    	*/
    	void SetPulseInTimeOut(UInt timeOut);

			//***
			// SONAR HC-SR04
			//***
			
    	/**
    	*Initializes the sonar reading feature. Needs HC-SR04 sonar module.
    	*level - level 0=none, 1=moderate, 2=strong.
			*Example (Private mfs As MultiFuncShield):<code>
    	*Private TriggerPinNr As Int = 5
    	*Private EchoPinNr As Int = 6
    	*Private TriggerPin As Pin
    	*Private EchoPin As Pin
			*
			*TriggerPin.Initialize(TriggerPinNr,TriggerPin.MODE_OUTPUT)
			*EchoPin.Initialize(EchoPinNr,EchoPin.MODE_INPUT)
			*EchoPin.DigitalWrite(False)
			*
			*InitSonar(mfs.SMOOTHING_STRONG)
			*</code>
    	*/
    	void InitSonar(Byte level); 

    	/**
    	*Gets the distance measured in centimeters, using HC-SR04 sonar module.
			*Example (Private mfs As MultiFuncShield):<code>
			*InitSonar(mfs.SMOOTHING_STRONG)
			*GetSonarDataCm(TriggerPinNr, EchoPinNr)
			*</code>
    	*/
    	UInt GetSonarDataCm(Byte triggerPin, Byte echoPin);

			//***
			// TEMPERATURE LM35
			//***

    	/**
    	*Initializes temperature reading feature. Needs LM35 sensor. Must remove jumper J1 from shield.
    	*level - level 0=none, 1=moderate, 2=strong.
			*Example (Private mfs As MultiFuncShield):<code>
			*InitLM35(mfs.SMOOTHING_MODERATE)
			*</code>
    	*/
    	void InitLM35(Byte level); 
 
    	/**
    	*Gets the temperature reading in 1 tenths of a centigrade.
			*Example (Private mfs As MultiFuncShield):<code>
			*Dim t As Double = mfs.GetLM35Data()
			*mfs.WriteDouble(t / 10, 1)
			*</code>
    	*/
    	Int GetLM35Data();


 	};
}