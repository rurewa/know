// B4R Library rMultiFuncShield
#include "B4RDefines.h"
#include "TimerOne.h"
namespace B4R {

    	// Initializes this instance, but interrupt based features are not available.
			void B4RMultiFuncShield::Initialize(){
				// Init the multi-function shield library
				MFS.initialize();
			}

    	// Initializes this instance using a TimerOne instance. A 1khz interrupt is attached. 
			void B4RMultiFuncShield::InitializeWithTimer(){
				// Init the timer (from TimerOne)
				Timer1.initialize();
				// Init the multi-function shield library
				MFS.initialize(&Timer1); 
 			}

    	void B4RMultiFuncShield::InitializeWithTimerLooper(SubVoidVoid SubName){
				// Init the timer (from TimerOne)
				Timer1.initialize();
				// Init the multi-function shield library
				MFS.initialize(&Timer1);
				// Init the looper
				union FunctionUnion fncu;
				fncu.LooperFunction = SubName;
				pollers.add(fncu, NULL);
     	}

			// ***
			// TIMER
			// ***

			// Initiates a millisecond countdown timer.
    	void B4RMultiFuncShield::SetTimer (ULong thousandths){
    		MFS.setTimer (thousandths);
    	}

    	// Gets the current value of the countdown timer.
    	ULong B4RMultiFuncShield::GetTimer(){
				return MFS.getTimer();    		
    	}

    	// Initiates and waits for millisecond countdown timer to reach 0.
			void B4RMultiFuncShield::Wait(ULong thousandths){
				MFS.wait(thousandths);		
			}

			// ***
			// LED DISPLAY
			// ***
    
    	void B4RMultiFuncShield::WriteString(B4RString* string, Byte rightJustify =0){
    		MFS.write(string->data, rightJustify);
    	}
    	
    	void B4RMultiFuncShield::WriteInt(Int integer){
	    	MFS.write(integer);
     	}
    		
			void B4RMultiFuncShield::WriteDouble(Double number, Byte decimalPlaces = 1){
	    	MFS.write(number, decimalPlaces);
			}


			void B4RMultiFuncShield::ManualDisplayRefresh(){
				MFS.manualDisplayRefresh();
			}
    
			void B4RMultiFuncShield::BlinkDisplay(Byte digits, Byte enabled = ON){
	    	MFS.blinkDisplay(digits, enabled);
				
			}
    
			void B4RMultiFuncShield::WriteLeds(Byte leds, Byte lit){
	    	MFS.writeLeds(leds, lit);
	    	//MFS.writeLeds(leds, lit);
			}

			void B4RMultiFuncShield::BlinkLeds(Byte leds, Byte enabled = ON){
    		MFS.blinkLeds(leds, enabled);
			}

			//***
			// BEEP
			//***

  	  void B4RMultiFuncShield::Beep(UInt onPeriod, UInt offPeriod, Byte cycles, UInt loopCycles, UInt loopDelayPeriod){
  	  	MFS.beep(onPeriod, offPeriod, cycles, loopCycles, loopDelayPeriod);
   	  }

    	void B4RMultiFuncShield::SetBeepOffPeriod(UInt offPeriod){
				MFS.setBeepOffPeriod(offPeriod);
     	}

			//***
			// BUTTONS
			//***
	
    	void B4RMultiFuncShield::QueueButton (Byte button){
				MFS.queueButton (button);
    	}

    	void B4RMultiFuncShield::ManualButtonHandler(){
				MFS.manualButtonHandler();
     	}

			void B4RMultiFuncShield::AddButtonListener(SubVoidByte Event) {
				this->Event = Event;
				FunctionUnion fu;
				fu.PollerFunction = buttonlooper;
				pollers.add(fu, this);
			}
			 
			void B4RMultiFuncShield::buttonlooper(void* b) {
				B4RMultiFuncShield* mf = (B4RMultiFuncShield*)b;
				Byte newValue = MFS.getButton();
				if (newValue != mf->ButtonCurrentValue) {
					sender->wrapPointer(mf);
					mf->ButtonCurrentValue = newValue;
					mf->Event(newValue);
				}
			}

			//***
			// PULSEIN
			//***

    	void B4RMultiFuncShield::InitPulseInCounter(Byte pin, UInt timeOut, Byte trigger){
 				MFS.initPulseInCounter(pin,timeOut,trigger);
      }

    	void B4RMultiFuncShield::DisablePulseInCounter(){
				MFS.disablePulseInCounter();
    	}
    
    	UInt B4RMultiFuncShield::GetPulseInPeriod(){
				return MFS.getPulseInPeriod();
     	}

    	ULong B4RMultiFuncShield::GetPulseInTotalCount(){
				return MFS.getPulseInTotalCount();	
    	}

    	void B4RMultiFuncShield::ResetPulseInTotalCount(){
    			MFS.resetPulseInTotalCount();
     	}

    	void B4RMultiFuncShield::SetPulseInTimeOut(UInt timeOut){
				MFS.setPulseInTimeOut(timeOut);
    	}

			//***
			// SONAR HC-SR04
			//***
			
    	void B4RMultiFuncShield::InitSonar(Byte level){
    		MFS.initSonar(level);
     	} 

    	/**
    	*Gets the distance measured in centimeters, using HC-SR04 sonar module.
    	*/
    	UInt B4RMultiFuncShield::GetSonarDataCm(Byte triggerPin, Byte echoPin){
    		return MFS.getSonarDataCm(triggerPin, echoPin);
    	}

			//***
			// TEMPERATURE LM35
			//***

    	/**
    	*Initializes temperature reading feature. Needs LM35 sensor. Must remove jumper J1 from shield.
    	*/
    	void B4RMultiFuncShield::InitLM35(Byte level){
				MFS.initLM35(level);
	    }

    	/**
    	*Gets the temperature reading in 1 tenths of a centigrade.
    	*/
    	Int B4RMultiFuncShield::GetLM35Data(){
    		return MFS.getLM35Data();	
    	}

}

