B4R Library rMultiFuncShield - Example Programs
Status 20170213

01-LED Display
Write text, int and double to the 4 digit LED display.

02-LEDs
Turn the onboard LEDs (4) on / off or blink.

03-Button
Button listener for the 3 onboard buttons.

04-Buzzer
Show beep and repeating beep.

05-Countdown
Count down number using looper.

06-PotMeter
Turn the onboard potmeter and log its value.

07-PulseIn
Press button 1 multiple times and show the pulse on the LED display.

08-LM35
Log the temperature for the LM35 sensor.

09-DS18B20
Log the temperature for the DS18B20 sensor.

10-Sonar HC-SR04
Log the distance for the HC-SR04 distance sensor.

11-Clock
Set the hours (button 1), minutes (button 2) and start (or stop) the clock with button 3.
Long press button 1 or 2 increases the number faster.

12-SetClock
Set the clock via B4J application using the B4R Serializer.

99-InlineC
An example for direct usage of the MultiFuncShield Library. Requires the library to be installed in the Arduino IDE.

